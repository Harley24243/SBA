{-# LANGUAGE TemplateHaskell #-}
module Main (main) where

import Data.List (delete, find)
import Data.Set ( Set, toAscList, empty, member, delete, insert )
import Graphics.Gloss ( play, loadBMP )
import Graphics.Gloss.Data.Color
import Data.Char (digitToInt)
import Control.Lens (element, makeLenses, view)
import Control.Lens.Operators ((.~))
import Data.Maybe (isNothing, fromMaybe, isJust)
import Control.Lens.Combinators (set, over)
import Graphics.Gloss.Interface.IO.Interact
import System.Random (StdGen)

type Cell = Maybe Int

data CellMark = CellMark {
    _center :: Set Int,
    _corner :: Set Int
}
$(makeLenses ''CellMark)

type Grid = (Int, Int) -> Cell
type GridMark = (Int, Int) -> CellMark
type Solution = (Int, Int) -> Int
type Selection = [(Int, Int)]

data Input = Full | Corner | Center

data Player = Player {
    _index :: Int,
    _name :: String,
    _score :: Int,
    _health :: Int,
    _mark :: GridMark,
    _input :: Input
}
$(makeLenses ''Player)

type SDB = [(Grid, Solution)]

data Model = Model {
    _db :: SDB,
    _gen :: StdGen,
    _grid :: Grid,
    _selection :: Selection,
    _solution :: Solution,
    _players :: [Player],
    _turn :: Int,
    _timeLeft :: Int,
    _roundTime :: Int,
    _finished :: Bool,
    _end :: Bool,
    _winner :: Maybe Player
}
$(makeLenses ''Model)

dTextSize :: Float
dTextSize = 100

cellSize :: Float
cellSize = 60

sTextSize :: Float
sTextSize = cellSize * 0.8;

drawEmptyGrid :: Float -> Picture
drawEmptyGrid n = Pictures $ [1 .. 10] >>= \i ->
    [Line [(n, n*i), (n*10, n*i)], Line [(n*i, n), (n*i, n*10)]]

outerIndexTranslate :: Float -> Int -> Picture -> Picture
outerIndexTranslate s i
    | i == 0 = Translate (- (s * 0.3)) (- (s * 0.3))
    | i == 1 = Translate (s*0.3) (- (s * 0.3))
    | i == 2 = Translate (- (s * 0.3)) (s*0.3)
    | i == 3 = Translate (s*0.3) (s*0.3)
    | i == 4 = Translate 0 (- (s * 0.3))
    | i == 5 = Translate 0 (s*0.3)
    | i == 6 = Translate (- (s * 0.3)) 0
    | i == 7 = Translate (s*0.3) 0
    | otherwise = id

drawText :: String -> Picture
drawText str = Scale s s $ Text str
    where
        s = (cellSize / dTextSize) * 0.8

drawCell :: Cell -> CellMark -> Picture
drawCell (Just n) _ = Translate s s $ drawText (show n) where s = (cellSize - sTextSize) / 2
drawCell Nothing _ = Blank
-- drawCell Nothing m = Translate (cellSize * 0.4) (cellSize * 0.4) $ Pictures
--     $ Scale 0.25 0.25 (drawText (concatMap show (toAscList (_center m)))) : ts
--         where
--             (_, ts) =
--                 foldl'
--                     (\(i, ps) n -> (i+1, outerIndexTranslate cellSize i (Scale 0.5 0.5 (drawText (show n))) : ps))
--                     (0, [])
--                     (toAscList (_corner m))

drawGrid :: Float -> Grid -> GridMark -> Picture
drawGrid s g m = Pictures $ drawEmptyGrid s : do
    r <- [0 .. 8]
    c <- [0 .. 8]
    return
        $ Translate ((fromIntegral c + 1) * s) ((9 - fromIntegral r) * s)
        $ drawCell (g (r, c)) (m (r, c))

drawSelection :: Float -> Selection -> Picture
drawSelection s sel = Color aquamarine $ Pictures $ map f sel
    where
        f (r, c) = Translate ((fromIntegral c + 1.5) * s) ((9.5 - fromIntegral r) * s) $ rectangleSolid s s

drawIcon :: Player -> Picture
drawIcon player = Pictures [ Translate (l / 2) (sTextSize / 2) $ Color yellow $ rectangleSolid l (sTextSize * 1.5), drawText $ _name player ]
    where l = sTextSize * fromIntegral (length (_name player))

drawTimer :: Int -> Picture
drawTimer time = drawText $ concat [show (time `div` 60), " : ", show (time `mod` 60)]

drawHealth :: Player -> Picture
drawHealth player = drawText $ "Health : " ++ show (_health player)

drawScore :: Player -> Picture
drawScore player = drawText $ "Score : " ++ show (_score player)

drawPlayer :: Player -> Int -> Picture
drawPlayer player time = Pictures
    [ Translate 0 (sTextSize * 6) $ drawIcon player
    , Translate 0 (sTextSize * 4) $ drawTimer time
    , Translate 0 (sTextSize * 2) $ drawHealth player
    , drawScore player ]

drawWinner :: Maybe Player -> Picture
drawWinner mp = Pictures
    [ maybe (Translate (- (sTextSize * 5)) 0 $ Color red $ drawText "No one Wins")
        (\player -> Translate (- (sTextSize * 3)) 0 $ Color orange $ drawText $ _name player ++ " Wins!") mp
    , Translate 0 (- sTextSize) $ Color orange $ rectangleSolid (sTextSize * 4.5) (sTextSize * 1.2)
    , Translate (- (sTextSize * 2)) (- (sTextSize * 1.5)) $ drawText "Restart" ]

render :: Picture -> Model -> Picture
render bg model = Pictures
    [ Scale 1.2 1.2 bg
    , Translate 0 (-300) $ drawSelection cellSize $ _selection model
    , Translate 0 (-300) $ drawGrid cellSize (_grid model) $ _mark player
    , Translate (-400) (-100) $ drawPlayer player (_timeLeft model)
    , if _end model then Translate 0 (-300) $ drawWinner (_winner model) else Blank]
    where
        player = _players model !! _turn model

getBox :: (Int, Int) -> [(Int, Int)]
getBox (r, c) = [(r', c') | r' <- gen br, c' <- gen bc]
    where
        br = r `div` 3
        bc = c `div` 3
        gen :: Int -> [Int]
        gen n = [n*3 .. n*3+2]

isFinished :: Grid -> Solution -> Bool
isFinished g s = isNothing $ find (\c -> g c /= Just (s c)) [(r, c) | r <- [0..8], c <- [0..8]]

findNextPlayer :: [Player] -> Int -> Maybe Player
findNextPlayer ps t = find (\p' -> _health p' > 0) (sps ++ fps)
    where
        (fps, sps) = splitAt (t+1) ps

atRestartArea :: (Float, Float) -> Bool
atRestartArea (x, y) = x >= - (sTextSize * 4.5 / 2) && x <= sTextSize * 4.5 / 2 && y >= - (300 + sTextSize * 1.6) && y <= - (300 + sTextSize * 0.4)

handleEvent :: Event -> Model -> Model
handleEvent event model = case event of
    EventKey (MouseButton LeftButton) Up _ coor@(x, y) ->
        let
            c :: Int = floor (x / cellSize) - 1
            r :: Int = 9 - floor ((y + 300) / cellSize)
            sel = _selection model
        in
        if c >= 0 && c < 9 && r >= 0 && r < 9
        then set selection (if (r, c) `elem` sel then Data.List.delete (r, c) sel else (r, c) : sel) model
        else if _end model && atRestartArea coor then initModel else model
    -- EventKey (Char ch) Up (Modifiers Down _ _) _ ->
    --     if ch `elem` ['1' .. '9']
    --     then
    --         let
    --             t = _turn model
    --             sel = _selection model
    --             n = digitToInt ch
    --         in
    --         over players (\ps ->
    --             element t .~ over mark (\m c ->
    --                 if c `elem` sel
    --                 then over corner (\cs ->
    --                     if member n cs
    --                     then Data.Set.delete n cs
    --                     else insert n cs) (m c)
    --                 else m c) (ps !! t) $ ps) model
    --     else model
    -- EventKey (Char ch) Up (Modifiers _ Down _) _ ->
    --     if ch `elem` ['1' .. '9']
    --     then
    --         let
    --             t = _turn model
    --             sel = _selection model
    --             n = digitToInt ch
    --         in
    --         over players (\ps ->
    --             element t .~ over mark (\m c ->
    --                 if c `elem` sel
    --                 then over center (\cs ->
    --                     if member n cs
    --                     then Data.Set.delete n cs
    --                     else insert n cs) (m c)
    --                 else m c) (ps !! t) $ ps) model
    --     else model
    EventKey (Char ch) Up _ _ ->
        let
            g = _grid model
            sel = _selection model
        in
        case sel of
            [coor@(r, c)] ->
                if not (_end model) && ch `elem` ['1' .. '9'] && isNothing (g coor)
                then
                    let
                        n = digitToInt ch
                        correct = _solution model coor == n
                        t = _turn model
                        emptyCnt :: [(Int, Int)] -> Int
                        emptyCnt = length . filter isNothing . map g
                        mult = min (emptyCnt [(r, c') | c' <- [0..8]])
                            (min (emptyCnt [(r', c) | r' <- [0..8]]) (emptyCnt $ getBox coor))
                    in
                    (\m -> set end (isJust (view winner m) || view health (view players m !! view turn m) <= 0) m)
                        $ (\m -> set winner (if view turn m == t && view finished m then Just (view players m !! t) else Nothing) m)
                        $ (\m -> set finished (isFinished (view grid m) (view solution m)) m)
                        $ (\m -> set turn (maybe (view turn m) _index (findNextPlayer (view players m) (view turn m))) m)
                        $ set selection []
                        $ (\m -> set timeLeft (_roundTime m) m)
                        $ (\m -> over players (\ps ->
                            let p = ps !! view turn m in
                            element (view turn m) .~ over health (\h -> if correct then h else h-1)
                                (over score (if correct then (+ _timeLeft m * mult) else id) p) $ ps) m)
                        $ set grid (if correct then \coor' -> if coor' == coor then Just n else g coor' else g) model
                else model
            _ -> model
    _ -> model


step :: Float -> Model -> Model
step _ model =
    (\m -> over end (\e -> e || view health (view players m !! view turn m) <= 0) m)
        $ (\m -> over turn (\t -> if view timeLeft m <= 0 then maybe t _index (findNextPlayer (view players m) t) else t) m)
        $ (\m -> set selection (if view timeLeft m <= 0 then [] else _selection m) m)
        $ (\m -> over players (element (view turn m) .~ over health (\h -> if view timeLeft m <= 0 && h > 0 then h - 1 else h) (view players m !! view turn m)) m)
        $ (\m -> if view finished m || view end m then m else over timeLeft (\tl -> if tl > 0 then tl - 1 else _roundTime m) m) model

parseCell :: Char -> Cell
parseCell '0' = Nothing
parseCell c = Just $ digitToInt c

parseGrid :: String -> Grid
parseGrid s (r, c) = parseCell $ s !! (r * 9 + c)

parseSolution :: String -> Solution
parseSolution s (r, c) = digitToInt $ s !! (r * 9 + c)


egGrid :: String
egGrid = "123456780456709123089123450234067891567891230891204567345678910678902345912345678"

egSolution :: String
egSolution = "123456789456789123789123456234567891567891234891234567345678912678912345912345678"

emptyGridMark :: GridMark
emptyGridMark _ = CellMark empty empty

initModel :: SDB -> Model
initModel sdb = Model {
    _db = sdb,
    _grid = parseGrid egGrid,
    _selection = [],
    _solution = parseSolution egSolution,
    _players =
        [ Player 0 "P1" 0  5 emptyGridMark Full
        , Player 1 "P2" 0  5 emptyGridMark Full],
    _turn = 0,
    _timeLeft = 10,
    _roundTime = 10,
    _finished = False,
    _end = False,
    _winner = Nothing
}

pairAll :: [a] -> [(a, a)]
pairAll [] = []
pairAll [_] = []
pairAll (x:y:xs) = (x, y) : pairAll xs

main :: IO ()
main = do
    raw <- readFile "sudoku.txt"
    background <- loadBMP "background.bmp"
    play
        (InWindow "SBA" (1800, 1000) (10, 10))
        black               -- background color
        1                   -- frame per second
        (initModel $ map (\(sg, ss) -> (parseGrid sg, parseSolution ss)) $ pairAll $ filter (\s -> length s == 81) $ lines raw)
        (render background) -- picture to display
        handleEvent
        step